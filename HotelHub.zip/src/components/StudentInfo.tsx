/**
 * Student Information Component
 * Displays college student details including personal and academic information
 */

import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, GraduationCap, Building, Calendar, Hash, Edit3, Save, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';

interface StudentData {
  name: string;
  email: string;
  phone: string;
  address: string;
  registerNumber: string;
  collegeName: string;
  branch: string;
  year: string;
}

/**
 * Main Student Information Component
 */
export default function StudentInfo() {
  const [isEditing, setIsEditing] = useState(false);
  const [studentData, setStudentData] = useState<StudentData>({
    name: 'John Doe',
    email: 'john.doe@student.govpolytechnic.edu',
    phone: '+91 9876543210',
    address: '123 College Street, Academic City, State - 560001',
    registerNumber: 'GP/CS/23/001',
    collegeName: 'Government Polytechnic',
    branch: 'Computer Science',
    year: '23-2026'
  });

  const [editData, setEditData] = useState<StudentData>(studentData);

  /**
   * Handle save functionality
   */
  const handleSave = () => {
    setStudentData(editData);
    setIsEditing(false);
  };

  /**
   * Handle cancel functionality
   */
  const handleCancel = () => {
    setEditData(studentData);
    setIsEditing(false);
  };

  /**
   * Handle input changes
   */
  const handleInputChange = (field: keyof StudentData, value: string) => {
    setEditData({ ...editData, [field]: value });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
              <GraduationCap className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Student Information System</h1>
          <p className="text-lg text-gray-600">{studentData.collegeName}</p>
        </div>

        {/* Main Student Card */}
        <Card className="mb-8 shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl font-bold flex items-center gap-3">
                  <User className="w-8 h-8" />
                  Student Profile
                </CardTitle>
                <CardDescription className="text-blue-100 mt-2">
                  Personal and Academic Information
                </CardDescription>
              </div>
              <div className="flex gap-2">
                {!isEditing ? (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setIsEditing(true)}
                    className="bg-white/20 text-white border-white/30 hover:bg-white/30"
                  >
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleSave}
                      className="bg-green-500 text-white border-green-600 hover:bg-green-600"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleCancel}
                      className="bg-red-500 text-white border-red-600 hover:bg-red-600"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Personal Information */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <User className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">Personal Information</h3>
                </div>

                {/* Name */}
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Full Name
                  </Label>
                  {isEditing ? (
                    <Input
                      id="name"
                      value={editData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <p className="text-lg text-gray-900 font-medium bg-gray-50 p-3 rounded-lg">
                      {studentData.name}
                    </p>
                  )}
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address
                  </Label>
                  {isEditing ? (
                    <Input
                      id="email"
                      type="email"
                      value={editData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded-lg">
                      {studentData.email}
                    </p>
                  )}
                </div>

                {/* Phone */}
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number
                  </Label>
                  {isEditing ? (
                    <Input
                      id="phone"
                      value={editData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded-lg">
                      {studentData.phone}
                    </p>
                  )}
                </div>

                {/* Address */}
                <div className="space-y-2">
                  <Label htmlFor="address" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Physical Address
                  </Label>
                  {isEditing ? (
                    <Input
                      id="address"
                      value={editData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded-lg">
                      {studentData.address}
                    </p>
                  )}
                </div>
              </div>

              {/* Academic Information */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <GraduationCap className="w-6 h-6 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">Academic Information</h3>
                </div>

                {/* Register Number */}
                <div className="space-y-2">
                  <Label htmlFor="registerNumber" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Hash className="w-4 h-4" />
                    Register Number
                  </Label>
                  {isEditing ? (
                    <Input
                      id="registerNumber"
                      value={editData.registerNumber}
                      onChange={(e) => handleInputChange('registerNumber', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
                      <p className="text-xl text-blue-800 font-bold">
                        {studentData.registerNumber}
                      </p>
                    </div>
                  )}
                </div>

                {/* College Name */}
                <div className="space-y-2">
                  <Label htmlFor="collegeName" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Building className="w-4 h-4" />
                    College Name
                  </Label>
                  {isEditing ? (
                    <Input
                      id="collegeName"
                      value={editData.collegeName}
                      onChange={(e) => handleInputChange('collegeName', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <p className="text-lg text-gray-900 font-semibold bg-gray-50 p-3 rounded-lg">
                      {studentData.collegeName}
                    </p>
                  )}
                </div>

                {/* Branch */}
                <div className="space-y-2">
                  <Label htmlFor="branch" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <GraduationCap className="w-4 h-4" />
                    Branch
                  </Label>
                  {isEditing ? (
                    <Input
                      id="branch"
                      value={editData.branch}
                      onChange={(e) => handleInputChange('branch', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-600 text-white text-base px-4 py-2">
                        {studentData.branch}
                      </Badge>
                    </div>
                  )}
                </div>

                {/* Academic Year */}
                <div className="space-y-2">
                  <Label htmlFor="year" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Academic Year
                  </Label>
                  {isEditing ? (
                    <Input
                      id="year"
                      value={editData.year}
                      onChange={(e) => handleInputChange('year', e.target.value)}
                      className="border-gray-300 focus:border-blue-500"
                    />
                  ) : (
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                      <p className="text-lg text-green-800 font-semibold">
                        Final Year: {studentData.year}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Status Card */}
            <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <GraduationCap className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-green-800">Student Status</h4>
                    <p className="text-green-600">Active - Final Year</p>
                  </div>
                </div>
                <Badge className="bg-green-500 text-white">
                  Active
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="hover:shadow-lg transition-shadow border-0 bg-white/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <User className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Profile Management</h4>
              <p className="text-sm text-gray-600">Update personal information</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow border-0 bg-white/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="w-6 h-6 text-indigo-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Academic Records</h4>
              <p className="text-sm text-gray-600">View grades and transcripts</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow border-0 bg-white/80">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-6 h-6 text-green-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Schedule</h4>
              <p className="text-sm text-gray-600">View class timetable</p>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center text-gray-600">
          <p>&copy; 2025 Government Polytechnic - Student Information System</p>
        </footer>
      </div>
    </div>
  );
}
