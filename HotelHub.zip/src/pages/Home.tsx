/**
 * College Student Information System Homepage
 * Displays the main student information interface
 */

import React from 'react';
import StudentInfo from '../components/StudentInfo';

/**
 * Main Homepage Component
 */
export default function Home() {
  return <StudentInfo />;
}
